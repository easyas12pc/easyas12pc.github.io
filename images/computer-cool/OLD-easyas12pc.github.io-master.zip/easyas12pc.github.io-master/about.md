---
layout: page
title: About
permalink: /about/
---

My name is William (Billy) Winslow, and I am an <strike>IT Support Technician</strike>, a <strike>Web Developer</strike>, a <strike>Customer Service Advisor</strike> all of these.

### More Information

I have strived to be the best of these that I can be during my working life and many more besides. I have many years experience supporting computer users in small medium and even large companies at various levels. I have been a member of a large IT support helpdesk and I have been the only helpdesk agent in other roles. I work very hard towards being the best that I can be whether that is an IT Support Techician or a Customer Service Advisor.

### Contact me

[info@easyas12pc.co.uk](mailto:info@easyas12pc)
